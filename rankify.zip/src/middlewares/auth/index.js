const userAuth = require('./userAuth');
const adminAuth = require('./adminAuth');


module.exports = {
    userAuth,
    adminAuth
}