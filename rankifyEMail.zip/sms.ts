const key = 'e1da34c59d7ab6d9';

var request = require("request");
var options = { method: 'GET',
url: 'https://api.authkey.io/request',
qs: 
{ authkey: key,
sms: 'Hello, This is test message from Authkey.io',
mobile: '03163801009',
country_code: '92',
sender: 'SENDERID' },
};

request(options, function (error, response, body) {
if (error) throw new Error(error);

console.log(body);
});